# 如何把这次修改更新到已有 GitHub 项目

这次只在本机修改和打包，没有替你登录 GitHub、推送代码或创建 Pull Request。原目录是普通文件夹，没有 Git 提交记录；GitHub 仓库应以你实际使用的地址为准。

## 推荐：GitHub Desktop（适合第一次操作）

1. 安装并登录 GitHub Desktop。在菜单 File → Clone repository 中选择你的已有项目；如果当前项目属于别人，先在 GitHub 网页点 Fork，克隆你自己的 Fork。
2. 选择 E 盘作为本地保存位置。克隆完成后，在 Current Branch → New Branch 创建分支，例如 `manual-search-recovery`，避免直接在主分支上修改。
3. 解压本次 ZIP。把里面 `SheepSolver` 文件夹中的内容复制到刚克隆的仓库根目录，允许覆盖对应源码文件。目标根目录一般已有 README.md 和 LICENSE。不要再套一层 `SheepSolver/SheepSolver`，不要删除仓库的隐藏 `.git` 目录，也不要删除你原仓库独有的其他文件。
4. 打开 GitHub Desktop 的 Changes。逐个检查 diff：本次主要是新增手动控制 / 状态识别 / 部分路线搜索，修改执行器、电量规则、抓包默认行为、启动器、构建和说明文档。确认 `.venv`、`runtime`、证书、抓包记录和私人配置不在列表里。包里的 `.gitignore` 已排除这些目录，但已被 Git 跟踪的旧文件仍需人工检查。
5. 在克隆目录运行 `安装依赖.cmd`，再运行 `运行测试.cmd`。已安装 Python 3.12 与 .NET Framework C# 编译器时会构建并运行测试。本次交付的基准是 71 项：55 通过、16 因缺少旧素材跳过。测试不代表真实微信通关。
6. Summary 填 `Add manual search and verified partial-route recovery`，点击 Commit to manual-search-recovery。点击 Publish branch 或 Push origin，把分支上传到你的 GitHub。
7. 在 GitHub 网页点 Compare & pull request。标题可用“支持手动搜索、部分路线执行和道具后续算”。描述说明完成的功能、验证结果，以及洗牌隐藏状态和实局未验收的限制。点击 Create pull request。
8. Review changes 检查正确后再合并。自己的仓库可以点 Merge pull request；别人的项目需要维护者审核。合并之后代码才进入目标主分支。

这份修改沿用项目的 AGPL-3.0 许可证。保留 LICENSE、world_support/LICENSE、来源文件与作者归属；不要把他人项目改成没有授权依据的私有许可证。

## 想直接在 GitHub 网页改

- 改一个文件：打开文件 → 铅笔 Edit → 修改 → Commit changes → 选择新分支 → 发起 Pull Request。
- 上传多个文件：目标仓库 → Add file → Upload files。先解压 ZIP，再拖入里面的源码 / 文件夹，并保持原有相对路径。选择新分支后提交。
- 不要把整个 ZIP 当作代码上传。上传 ZIP 只是新增一个压缩附件，不会替换压缩包里的源文件。多文件和二进制更新更建议用 GitHub Desktop。
- 没有写权限时先 Fork；GitHub 网页编辑通常也会引导创建 Fork 和 Pull Request。

## 熟悉命令行后可用

```powershell
# 将占位地址替换成你的实际仓库，先克隆已有项目。
git clone https://github.com/YOUR_NAME/YOUR_REPO.git
cd YOUR_REPO
git switch -c manual-search-recovery
# 现在复制解压后的 SheepSolver 文件夹内容到当前仓库根目录。
git status --short
git diff --stat
git diff
# 确认变更只有预期源码 / 说明 / 构建产物，且没有本机运行数据，再暂存。
git add .
git diff --cached --stat
git commit -m "Add manual search and verified partial-route recovery"
git push -u origin manual-search-recovery
```

然后去 GitHub 创建 Pull Request。不要对已有仓库直接运行新的 `git init`，不要强推 `git push --force`，也不要把原仓库 `.git` 用 ZIP 文件替换。

## 本次使用入口

本机原目录已经更新，不必再次安装 Python：双击“手动搜索与续算.cmd”。保持抓包窗口开启；开始搜索 → 执行路线 → 停止后使用移出 → 重新识别 → 再次搜索 / 执行。

压缩包是可分发的源码与 Windows 程序包，没有本机虚拟环境、证书或采集状态。新位置解压运行需要重新建立 .venv，并按原说明配置代理证书。
