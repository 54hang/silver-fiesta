"""Manual search -> reviewed partial/full execution -> actual-state recovery."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
from app_bridge import read, capture_snapshot, inspect_board, geometry
from live_state import checkpoint, replay, export_route, verify_route
from color_rules import initial_cards
from solve_verified_map import atomic_json

ROOT = Path(__file__).resolve().parent


def history_after(solution, n):
    if not isinstance(n,int) or not 0 <= n <= len(solution['sequence']): raise ValueError('点击记录步数无效')
    history = list(solution['history']); board = replay(solution['cards'],solution.get('rules'),history)
    for id in solution['sequence'][:n]:
        history.append(dict(kind='return' if id in board.side else 'board',id=id))
        if id in board.side: board.return_card(id)
        else: board.move(id)
    return history


def recovery_histories(base, history, pending=None):
    result = [history]
    board = replay(base['cards'],base.get('rules'),history)
    if board.slot and not board.moved_out:
        result.append(history+[dict(kind='move_out')])
    # Undo only the most recent pick, and only when the previous board exactly
    # explains the current screen. The game's undo eligibility is not assumed.
    if history and history[-1]['kind'] in ('board','return') and not (base.get('rules') or {}).get('kind')=='energy_alien_v1':
        before=replay(base['cards'],base.get('rules'),history[:-1])
        if len(board.tray)==len(before.tray)+1:result.append(history[:-1])
    if pending:
        result.append(history+[dict(kind='return' if pending in board.side else 'board',id=pending)])
    unique = {json.dumps(h,sort_keys=True):h for h in result}
    return list(unique.values())


class Controller:
    def __init__(self, notify=print):
        self.notify = notify; self.process = None; self.folder = None; self.selection = None; self.ready = False

    def cancel(self):
        if self.folder:
            atomic_json(self.folder/'search_control.json',dict(action='stop'))
        if getattr(self,'play_folder',None):
            atomic_json(self.play_folder/'control.json',dict(action='stop'))

    def capture_pair(self, folder):
        from live_recognition import stable_images
        first = capture_snapshot(folder/'scan-first.png'); time.sleep(.4)
        second = capture_snapshot(folder/'scan-now.png'); stable_images(first,second)
        return second

    def refresh(self):
        """Only a successful fresh scan authorizes a new search or playback."""
        self.ready = False
        import world_solution, app_bridge
        status,path = world_solution.current(); world_solution.active_session(status)
        app_bridge.OUT = world_solution.ROOT/'runtime/world'
        session = path.parent
        saved_path = session/'live_checkpoint.json'
        saved = read(saved_path) if saved_path.exists() else {}
        self.folder = session/'live'; self.folder.mkdir(exist_ok=True)
        raw = self.capture_pair(self.folder)
        if saved:
            from app_bridge import fresh_board_candidates
            fresh=fresh_board_candidates(session,raw,len(status['map_ids']))
            if len(fresh)==1 and fresh[0]['level']!=saved['level']:
                saved={}
        if saved:
            level = saved['level']; mp = session/f'map_{level}.json'
            digest = hashlib.sha256(mp.read_bytes()).hexdigest()
            if saved['base']['map_sha256'] != digest: raise ValueError('地图已变更，请重新进入当前局')
            base = saved['base']; history = base['history']; pending = None
            original_cards,original_rules=initial_cards(read(mp))
            if base['cards']!=original_cards or base.get('rules')!=original_rules:
                raise ValueError('断点牌型或规则与当前源地图不一致')
            plan_path = Path(saved['plan_path']) if saved.get('plan_path') else None
            if plan_path and (plan_path.parent/'playback_status.json').exists():
                plan = read(plan_path); solution = read(Path(plan['solution_path']))
                ps = read(plan_path.parent/'playback_status.json'); n = ps['next_step']
                actions_path=plan_path.parent/'actions.jsonl'
                actions=[json.loads(line) for line in actions_path.read_text(encoding='utf-8-sig').splitlines() if line.strip()] if actions_path.exists() else []
                if len(actions)!=n or any(a['step']!=i+1 or a['card_id']!=solution['sequence'][i] for i,a in enumerate(actions)):
                    raise ValueError('已执行点击与日志不一致，停止续接')
                history = history_after(solution,n)
                if ps.get('input_pending') and n<len(solution['sequence']): pending = solution['sequence'][n]
            else: plan = saved['reference_plan']
            from live_recognition import templates_from_plan, reconcile
            templates = templates_from_plan(plan)
            candidates = recovery_histories(base,history,pending)
            history, observed = reconcile(raw,base,candidates,saved['calibration'],templates)
            base = dict(base,history=history)
            calibration = saved['calibration']
        else:
            selected = inspect_board(session,raw,len(status['map_ids']))
            level = selected['level']; mp = session/f'map_{level}.json'
            data = read(mp); base = checkpoint(data,hashlib.sha256(mp.read_bytes()).hexdigest())
            if selected.get('resume'):
                old = read(Path(selected['plan']['solution_path'])); n = selected['start_step']
                history=[]; board=replay(base['cards'],base.get('rules'),history)
                for id in old['sequence'][:n]: history.append(dict(kind='board',id=id)); board.move(id)
                base['history']=history; calibration=selected['plan']['calibration']
                from live_recognition import match_state, templates_from_plan
                observed=match_state(raw,base,history,calibration,templates_from_plan(selected['plan']))
            else:
                calibration=selected['calibration']; positions,anchors=geometry(base['cards'],calibration)
                observed=dict(positions=positions,side_positions={},tray=[],side=[],remaining=len(base['cards']))
        # Preserve samples from earlier checkpoints across move-outs and returns.
        from live_recognition import templates_from_plan
        if saved:
            templates=templates_from_plan(plan)
        elif selected.get('resume'):
            templates=templates_from_plan(selected['plan'])
        else:templates={}
        positions = observed['positions']; board = replay(base['cards'],base.get('rules'),base['history'])
        visible = [c for c in base['cards'] if c['id'] in board.remaining and board.exposed(c['id'])]
        anchors = [dict(id=c['id'],type=board.types[c['id']],center=positions[c['id']]) for c in visible]
        anchors += [dict(id=id,type=board.types[id],center=positions[id]) for id in board.side]
        reference=self.folder/f'reference-{time.time_ns()}.png'
        reference.write_bytes(raw.read_bytes())
        reference_plan=dict(reference_path=str(reference),anchors=anchors,map_sha256=base['map_sha256'])
        from PIL import Image
        bank=self.folder/'icon_bank';bank.mkdir(exist_ok=True)
        samples=templates_from_plan(reference_plan)
        for t,values in templates.items():samples.setdefault(t,[]).extend(values)
        for t,values in samples.items():
            # Bound disk and matching costs across repeated manual retries.
            import numpy as np
            unique=[]
            for array in values:
                if not any(np.array_equal(array,previous) for previous in unique):unique.append(array)
            for i,array in enumerate(unique[:8]):Image.fromarray(array.astype('uint8')).save(bank/f'{t}_{i}.png')
        reference_plan['icon_bank']=str(bank)
        saved=dict(level=level,base=base,calibration=calibration,observed=observed,reference_plan=reference_plan)
        atomic_json(saved_path,saved)
        self.saved=saved; self.saved_path=saved_path; self.status=status; self.mp=mp; self.reference=reference
        self.ready=True; self.selection=None
        self.notify(f'已重新获取实际状态：第 {level+1} 关，棋盘 {observed["remaining"]} 张，槽位 {observed["tray"]}，移出区 {observed["side"]}。可手动开始搜索。')

    def search(self, seconds=120, cancelled=lambda:False):
        self.refresh()
        if cancelled():
            self.notify('已停止，未启动新的搜索进程。');return
        base=self.saved['base']; atomic_json(self.folder/'input.json',base)
        for name in ('candidate.json','search_control.json','search_status.json'):
            (self.folder/name).unlink(missing_ok=True)
        self.notify(f'开始限时搜索（{seconds} 秒）。可随时停止，停止后保留独立验证通过的部分路线。')
        with (self.folder/'search.log').open('w',encoding='utf-8') as log:
            child=subprocess.Popen([str(ROOT/'LiveSearch.exe'),str(self.folder/'input.json'),str(self.folder/'candidate.json'),str(seconds)],
                                   stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
            self.process=child; started=last=time.monotonic()
            try:
                while child.poll() is None:
                    if cancelled(): self.cancel()
                    import world_solution
                    world_solution.active_session(self.status)
                    if time.monotonic()-started>seconds+10: raise TimeoutError('搜索未按期退出')
                    if time.monotonic()-last>5:
                        progress=read(self.folder/'search_status.json') if (self.folder/'search_status.json').exists() else {}
                        self.notify(f'搜索 {time.monotonic()-started:.0f} 秒，已检查 {progress.get("nodes",0)} 个状态，候选 {progress.get("deepest",0)} 步。');last=time.monotonic()
                    time.sleep(.1)
                if child.returncode not in (0,2): raise ValueError('搜索进程异常，请检查 live/search.log')
            finally:
                if child.poll() is None:
                    self.cancel()
                    try: child.wait(timeout=3)
                    except subprocess.TimeoutExpired: child.kill(); child.wait(timeout=3)
                self.process=None
        candidate=read(self.folder/'candidate.json')
        solution=export_route(base,candidate['sequence'])
        if not solution['sequence']:
            self.notify('计算已停止，没有可安全执行的路线。可使用道具后重新识别。');return
        self.selection=solution
        self.notify(('完整路线' if solution['complete'] else '部分路线')+f' {len(solution["sequence"])} 步已独立验证；计算已停止。点击“执行路线”启动，路线末尾自动停下。')

    def play(self, cancelled=lambda:False):
        if not self.ready or not self.selection: raise ValueError('请先重新识别并搜索出可执行路线')
        import world_solution
        world_solution.active_session(self.status)
        solution=self.selection; verify_route(solution)
        original_cards,original_rules=initial_cards(read(self.mp))
        if (hashlib.sha256(self.mp.read_bytes()).hexdigest()!=solution['map_sha256'] or
                solution['cards']!=original_cards or solution.get('rules')!=original_rules):
            raise ValueError('源地图或规则已变化，请重新识别')
        raw=self.capture_pair(self.folder)
        from live_recognition import stable_images
        stable_images(self.reference,raw)  # Invalidates the route after any human change.
        if cancelled():
            self.notify('已停止，未发送点击。');return
        stamp=str(time.time_ns()); play=self.folder/f'run-{stamp}';play.mkdir()
        solution_path=play/'solution.json';atomic_json(solution_path,solution)
        plan=dict(self.saved['reference_plan'],solution_path=str(solution_path),source_map_path=str(self.mp),
                  play_folder=str(play),
                  session=self.status['session'],mode='world' if '/world/' in self.status.get('source_path','') else 'daily',
                  map_sha256=solution['map_sha256'],positions=self.saved['observed']['positions'],calibration=self.saved['calibration'],
                  capture_status_path=str(world_solution.ROOT/'runtime/world/status.json'),service_lease_path=str(world_solution.ROOT/'runtime/world/service_lease.json'),
                  start_step=0,allow_live=True,dynamic_anchors=True,adaptive_verify=True,mark_milliseconds=450,verify_milliseconds=1100)
        plan_path=play/'plan.json';atomic_json(plan_path,plan)
        # Independent native replay is also required before enabling input.
        check=subprocess.run([str(ROOT/'SolverPlayback.exe'),str(plan_path),'--validate-only'],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=15)
        if check.returncode: raise ValueError(check.stderr.decode('utf-8-sig',errors='replace') or '独立执行器校验失败')
        self.saved['plan_path']=str(plan_path);atomic_json(self.saved_path,self.saved)
        self.play_folder=play;self.ready=False;self.selection=None
        self.notify('执行已启动，F8 暂停/继续，F9 或“停止”结束。')
        child=subprocess.Popen([str(ROOT/'SolverPlayback.exe'),str(plan_path)],creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            while child.poll() is None:
                if cancelled(): self.cancel()
                time.sleep(.1)
            result=read(play/'playback_status.json') if (play/'playback_status.json').exists() else {}
            self.notify('执行已停止。'+result.get('message','请重新识别实际状态。')+' 使用道具后点击“重新识别”，再开始搜索。')
        finally:
            self.play_folder=None


def serve():
    """Line-oriented UI bridge. Stop is processed while a worker is searching."""
    import threading
    from world_solution import execution_lock
    output_lock=threading.Lock()
    stop=threading.Event();worker=None
    def emit(message,kind='message'):
        with output_lock:
            print(json.dumps(dict(kind=kind,message=str(message)),ensure_ascii=False),flush=True)
    controller=Controller(emit)
    def work(action,seconds):
        try:
            with execution_lock():
                if action=='refresh':controller.refresh()
                elif action=='search':controller.search(seconds,stop.is_set)
                elif action=='play':controller.play(stop.is_set)
                else:raise ValueError('未知操作')
        except Exception as error:
            controller.ready=False;controller.selection=None;emit(error)
        finally:emit('操作结束','idle')
    emit('保持抓包窗口开启并显示游戏棋盘。手动开始搜索，路线验证后另点执行。','ready')
    try:
        for line in __import__('sys').stdin:
            try:
                command=json.loads(line);action=command['action']
                if action=='stop':stop.set();emit('已请求停止，等待正在确认的点击或搜索进程结束。');continue
                if action=='close':break
                if worker and worker.is_alive():emit('当前操作尚未结束，请先停止。');continue
                seconds=int(command.get('seconds',120))
                if not 1<=seconds<=300:raise ValueError('搜索时限应为 1–300 秒')
                stop.clear();worker=threading.Thread(target=work,args=(action,seconds));worker.start()
            except (ValueError,KeyError,TypeError) as error:emit(error)
    finally:
        stop.set()
        if worker:worker.join()


def main():
    if '--serve' in __import__('sys').argv:serve();return
    subprocess.run([str(ROOT/'ManualControl.exe')],cwd=ROOT,check=True)


if __name__=='__main__':main()
