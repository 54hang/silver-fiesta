"""Reconcile stable screenshots with exact checkpoints; never infer hidden tiles."""
import copy
from pathlib import Path
import numpy as np
from PIL import Image
from board_align import exposed, face_offsets, energy_face, check_silhouette, _face_centers, pale_faces
from app_bridge import pattern_score, tray_count, read
from live_state import replay


def stable_images(first, second):
    a = np.asarray(Image.open(first).convert('RGB'), dtype=np.int16)
    b = np.asarray(Image.open(second).convert('RGB'), dtype=np.int16)
    if a.shape != (622,336,3) or b.shape != a.shape:
        raise ValueError('截图尺寸应为 336×622')
    # Includes the board, side area and all seven tray slots.
    delta=np.abs(a-b).sum(axis=2)
    if any(delta[y:y+20,x:x+20].mean()>6 for y in range(118,538,20) for x in range(20,316,20)):
        raise ValueError('牌面、牌槽或移出区仍在动画中，请稍后重新识别')
    return b


def templates_from_plan(plan):
    result = {}
    def add(t, image, x, y):
        if 18 <= x < 318 and 18 <= y < 604:
            result.setdefault(t, []).append(image[y-18:y+18,x-17:x+17])
    reference = np.asarray(Image.open(plan['reference_path']).convert('RGB'), dtype=np.int16)
    for anchor in plan['anchors']: add(anchor['type'], reference, *anchor['center'])
    if plan.get('icon_bank'):
        for p in Path(plan['icon_bank']).glob('*.png'):
            result.setdefault(int(p.stem.split('_')[0]),[]).append(np.asarray(Image.open(p).convert('RGB'),dtype=np.int16))
    play = Path(plan.get('play_folder',Path(plan['reference_path']).parent))
    context = read(play/'templates/context.json') if (play/'templates/context.json').exists() else {}
    if context.get('map_sha256') == plan['map_sha256']:
        for p in (play/'templates').glob('type_*.png'):
            result.setdefault(int(p.stem[5:]), []).append(np.asarray(Image.open(p).convert('RGB'),dtype=np.int16))
    if (play/'last_verified.png').exists():
        solution = read(Path(plan['solution_path']))
        if solution.get('execution_kind') == 'live_snapshot_v1':
            status = read(play/'playback_status.json'); n = status['next_step']
            from live_control import history_after
            board = replay(solution['cards'], solution.get('rules'), history_after(solution,n))
            last = np.asarray(Image.open(play/'last_verified.png').convert('RGB'),dtype=np.int16)
            for k,id in enumerate(board.slot): add(board.types[id], last, 43+42*k, 511)
            # The executor also learns newly uncovered stable faces from the
            # verified map. The last pick can uncover a type it never clicked.
            for id in board.remaining:
                if board.exposed(id) and not result.get(board.types[id]):
                    add(board.types[id],last,*plan['positions'][id])
            for id in board.side:
                if id in plan['positions']:add(board.types[id],last,*plan['positions'][id])
    return result


def known_icon(image, point, t, templates):
    """An icon must match its expected type and win against other known types."""
    scores = {kind: pattern_score(image, point, values) for kind,values in templates.items()}
    score = scores.get(t,1000)
    other = min((s for k,s in scores.items() if k != t),default=1000)
    if score > 60 or other < score + 12:
        raise ValueError(f'牌型 {t} 无法唯一识别，请保留现场并重试')


def match_state(image_path, base, history, calibration, templates):
    board = replay(base['cards'],base.get('rules'),history)
    image = np.asarray(Image.open(image_path).convert('RGB'),dtype=np.int16)
    cards = [{**c,'type':board.types[c['id']]} for c in base['cards'] if c['id'] in board.remaining]
    positions = {c['id']:[round(calibration['x_origin']+c['rolNum']*calibration['x_unit']),
                         round(calibration['y_origin']+c['rowNum']*calibration['y_unit'])] for c in cards}
    for c in exposed(cards):
        x,y = positions[c['id']]
        if not (20<=x<=315 and 125<=y<=465): raise ValueError('牌面坐标越界')
        pale = sum(image[y+dy,x+dx,0]>205 and image[y+dy,x+dx,1]>205 and image[y+dy,x+dx,2]>145
                   for dx,dy in face_offsets(calibration)) >= 5
        battery = c.get('metaType') == 3
        if not pale and not (battery and energy_face(image,(x,y))): raise ValueError('实际棋盘缺少预期可见牌')
        # Freshly exposed icons need a previously verified sample to resume.
        known_icon(image,(x,y),c['type'],templates)
    # Detect actual side tiles outside the remaining-board footprint. Shift
    # the lower strip so the existing connected-frame detector also sees y=480.
    pale = pale_faces(image)
    side_mask = np.zeros_like(pale); side_mask[410:480,20:316] = pale[410:480,20:316]
    for x,y in positions.values(): side_mask[max(0,y-24):min(622,y+24),max(0,x-22):min(336,x+22)] = False
    shifted = np.zeros_like(pale); shifted[380:450] = side_mask[410:480]
    centers = [(round(x),round(y+30)) for x,y in _face_centers(shifted)]
    centers.sort()
    if len(centers) != len(board.side): raise ValueError('实际移出区数量与状态不符')
    for id,point in zip(board.side,centers):
        known_icon(image,point,board.types[id],templates); positions[id] = list(point)
    # Include side footprints only for the silhouette gate, not for coverage.
    silhouette = copy.deepcopy(cards)
    for id,(x,y) in zip(board.side,centers):
        silhouette.append(dict(id=id,layer=1000,rolNum=(x-calibration['x_origin'])/calibration['x_unit'],
                               rowNum=(y-calibration['y_origin'])/calibration['y_unit'],type=board.types[id]))
    if silhouette: check_silhouette(image_path,silhouette,calibration)
    elif pale_faces(image)[118:466,20:316].sum()>50: raise ValueError('空棋盘出现额外牌块')
    if tray_count(Image.fromarray(image.astype(np.uint8))) != len(board.slot): raise ValueError('实际牌槽数量与状态不符')
    for k,id in enumerate(board.slot): known_icon(image,(43+42*k,511),board.types[id],templates)
    return dict(positions=positions,side_positions={id:positions[id] for id in board.side},
                tray=[board.types[id] for id in board.slot],side=[board.types[id] for id in board.side],
                remaining=len(board.remaining))


def reconcile(image_path, base, histories, calibration, templates):
    matches = []; errors = []
    for history in histories:
        try: matches.append((history,match_state(image_path,base,history,calibration,templates)))
        except (ValueError,KeyError) as error: errors.append(str(error))
    if not matches: raise ValueError('实际牌面、槽位或移出区未通过核对：'+(errors[0] if errors else '没有状态记录'))
    # Identical-looking same-type IDs may still consume different seeded state.
    if len(matches) != 1: raise ValueError('截图对应多个断点，不能确定实际状态；已停用旧路线')
    return matches[0]
