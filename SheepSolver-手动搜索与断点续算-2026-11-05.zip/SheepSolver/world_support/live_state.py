"""Exact, replayable checkpoints. A partial route never claims a win."""
import copy
from color_rules import ColorState, initial_cards
from energy_rules import EnergyBoard


class ClassicBoard:
    def __init__(self, cards, rules):
        self.cards = {c['id']: c for c in cards}
        self.color = ColorState(cards, rules)
        self.types = self.color.types
        self.remaining = self.color.remaining
        self.tray_ids = []; self.slot = []; self.side = []; self.moved_out = False

    @property
    def tray(self):
        return [self.types[i] for i in self.tray_ids]

    def exposed(self, id):
        c = self.cards[id]
        return id in self.remaining and not any(
            self.cards[p]['layer'] > c['layer'] and
            abs(self.cards[p]['rolNum']-c['rolNum']) < 8 and
            abs(self.cards[p]['rowNum']-c['rowNum']) < 8 for p in self.remaining)

    def move_out(self):
        if self.moved_out or not self.slot: raise ValueError('移出不可用')
        self.side = self.slot[:3]; self.slot = self.slot[3:]; self.remaining.difference_update(self.side)
        self.color.remaining.difference_update(self.side); self.moved_out = True
        self.tray_ids = [i for i in self.tray_ids if i not in self.side]

    def move(self, id):
        self._pick(id, False)

    def return_card(self, id):
        self._pick(id, True)

    def _pick(self, id, side):
        if (id not in self.side if side else not self.exposed(id)):
            raise ValueError('牌不存在、已点击或仍被遮挡')
        t = self.types[id]; tray = self.tray + [t]; crush = tray.count(t) == 3
        if not crush and len(tray) >= 7: raise ValueError('该步会填满七格牌槽')
        same = [k for k, i in enumerate(self.slot) if self.types[i] == t]
        self.slot.insert(same[-1]+1 if same else len(self.slot), id)
        self.tray_ids.append(id)
        if crush:
            self.slot = [i for i in self.slot if self.types[i] != t]
            self.tray_ids = [i for i in self.tray_ids if self.types[i] != t]
        if side:
            self.side.remove(id)
            # A returned changing tile is already outside the board pool.
            if crush and self.color.rng:
                ids = [i for i in self.color.special if i in self.remaining]
                values = [self.types[i] for i in ids]
                if len(values) > 1: self.color.rng.shuffle(values, len(values))
                self.types.update(zip(ids, values))
        else: self.color.remove(id, crush)


def replay(cards, rules, history):
    board = EnergyBoard(cards, rules) if (rules or {}).get('kind') == 'energy_alien_v1' else ClassicBoard(cards, rules)
    for action in history:
        kind = action['kind']
        if kind == 'move_out': board.move_out()
        elif kind == 'return': board.return_card(action['id'])
        elif kind == 'board': board.move(action['id'])
        else: raise ValueError('未知状态操作')
    return board


def checkpoint(data, digest, history=()):
    cards, rules = initial_cards(data)
    replay(cards, rules, history)
    return dict(cards=cards, rules=rules, history=list(history), map_sha256=digest)


def verify_route(payload):
    """Independent replay, including held tiles, side returns and seeded rules."""
    board = replay(payload['cards'], payload.get('rules'), payload['history'])
    seen = []; peak = len(board.tray)
    for id in payload['sequence']:
        seen.append(board.types[id])
        if id in board.side: board.return_card(id)
        else: board.move(id)
        peak = max(peak, len(board.tray))
    complete = not board.remaining and not board.side and not board.tray
    if payload.get('sequence_types', seen) != seen: raise ValueError('路线牌型与独立回放不一致')
    if payload.get('complete', complete) != complete: raise ValueError('路线完成标志不一致')
    if payload.get('expected_tray', list(board.tray)) != list(board.tray): raise ValueError('路线终点牌槽不一致')
    if not complete and len(board.tray) > 5: raise ValueError('部分路线没有预留至少两格牌槽')
    return board, seen, peak


def export_route(base, sequence):
    """Trim invalid/overflow steps, then leave two free slots at a partial end."""
    board = replay(base['cards'], base.get('rules'), base['history']); safe = []
    for id in sequence:
        trial = copy.deepcopy(board)
        try:
            if id in trial.side: trial.return_card(id)
            else: trial.move(id)
        except (ValueError, KeyError): break
        safe.append(id); board = trial
    while safe and (board.remaining or board.side or board.tray) and len(board.tray) > 5:
        safe.pop(); board = replay(base['cards'], base.get('rules'), base['history'])
        for id in safe:
            if id in board.side: board.return_card(id)
            else: board.move(id)
    result = dict(base, sequence=safe, complete=not board.remaining and not board.side and not board.tray,
                  expected_tray=list(board.tray), execution_kind='live_snapshot_v1', validated=False)
    _, types, peak = verify_route(result)
    result.update(sequence_types=types, segment_validated=True, peak_tray=peak)
    return result
