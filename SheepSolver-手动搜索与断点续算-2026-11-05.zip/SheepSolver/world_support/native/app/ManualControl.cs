using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Runtime.InteropServices;

// Small native control surface; the persistent Python bridge owns checkpoints.
class ManualControl:Form {
    [DllImport("user32.dll")]static extern short GetAsyncKeyState(int key);
    Process bridge;TextBox log;NumericUpDown seconds;Button search,refresh,play,stop;
    JavaScriptSerializer json=new JavaScriptSerializer();bool busy,closing,oldStop;Timer timer;
    bool smoke;int smokeResult=1;
    void Note(string message){log.AppendText(message+Environment.NewLine);}
    void EnabledActions(bool enabled){search.Enabled=refresh.Enabled=play.Enabled=enabled;}
    void Send(string action){
        try{if(bridge==null||bridge.HasExited)throw new Exception("控制进程已退出，请关闭并重新打开窗口。");
            if(action!="stop"&&action!="close"){busy=true;EnabledActions(false);}
            bridge.StandardInput.WriteLine(json.Serialize(new{action,seconds=(int)seconds.Value}));bridge.StandardInput.Flush();
        }catch(Exception e){Note(e.Message);busy=false;EnabledActions(false);}
    }
    public ManualControl(bool test){
        smoke=test;Text="羊了个羊 · 手动搜索与断点续算";ClientSize=new Size(900,520);MinimumSize=new Size(800,420);
        Font=new Font("Microsoft YaHei UI",10);StartPosition=FormStartPosition.CenterScreen;
        var help=new Label{Text="手动搜索 → 执行已验证路线 → 停下用道具 → 重新识别 → 再次搜索\nF9 停止搜索/执行；F8 暂停/继续点击。抓包只还原地图。",Dock=DockStyle.Top,Height=65,Padding=new Padding(16,10,8,0)};Controls.Add(help);
        var row=new FlowLayoutPanel{Dock=DockStyle.Top,Height=48,Padding=new Padding(12,5,0,0),WrapContents=false};
        row.Controls.Add(new Label{Text="搜索上限（秒）",AutoSize=true,Margin=new Padding(3,7,0,0)});
        seconds=new NumericUpDown{Minimum=1,Maximum=300,Value=120,Width=65};row.Controls.Add(seconds);
        refresh=new Button{Text="重新识别（道具后）",AutoSize=true};refresh.Click+=delegate{Send("refresh");};row.Controls.Add(refresh);
        search=new Button{Text="开始搜索",AutoSize=true};search.Click+=delegate{Send("search");};row.Controls.Add(search);
        play=new Button{Text="执行路线",AutoSize=true};play.Click+=delegate{Send("play");};row.Controls.Add(play);
        stop=new Button{Text="停止搜索 / 执行",AutoSize=true};stop.Click+=delegate{Send("stop");};row.Controls.Add(stop);
        Controls.Add(row);row.BringToFront();
        log=new TextBox{Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,Dock=DockStyle.Fill,BackColor=Color.White,Margin=new Padding(16)};Controls.Add(log);log.BringToFront();
        EnabledActions(false);
        Shown+=delegate{StartBridge();};
        FormClosing+=delegate(object sender,FormClosingEventArgs e){
            if(bridge!=null&&!bridge.HasExited){closing=true;e.Cancel=true;EnabledActions(false);Send("close");Note("正在停止并保存点击断点，请稍候…");}
        };
        timer=new Timer{Interval=100};timer.Tick+=delegate{
            bool key=(GetAsyncKeyState(0x78)&0x8000)!=0;if(key&&!oldStop)Send("stop");oldStop=key;
            if(bridge!=null&&bridge.HasExited){if(closing){timer.Stop();Close();}else if(busy){busy=false;EnabledActions(false);Note("控制进程已退出。请查看上方错误后重新打开窗口。");}}
        };timer.Start();
    }
    void StartBridge(){
        string support=AppDomain.CurrentDomain.BaseDirectory,root=Directory.GetParent(support.TrimEnd(Path.DirectorySeparatorChar)).FullName;
        var info=new ProcessStartInfo{FileName=Path.Combine(root,".venv","Scripts","python.exe"),Arguments="\""+Path.Combine(support,"live_control.py")+"\" --serve",
            WorkingDirectory=root,UseShellExecute=false,CreateNoWindow=true,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true,
            StandardOutputEncoding=Encoding.UTF8,StandardErrorEncoding=Encoding.UTF8};
        info.EnvironmentVariables["PYTHONUTF8"]="1";info.EnvironmentVariables["PYTHONPATH"]=root+Path.PathSeparator+support;
        try{
            bridge=new Process{StartInfo=info,EnableRaisingEvents=true};
            bridge.OutputDataReceived+=delegate(object sender,DataReceivedEventArgs e){if(e.Data==null)return;Post(delegate{try{
                var value=json.Deserialize<System.Collections.Generic.Dictionary<string,object>>(e.Data);
                string kind=value.ContainsKey("kind")?Convert.ToString(value["kind"]):"";
                if(value.ContainsKey("message"))Note(Convert.ToString(value["message"]));
                if(kind=="idle"||kind=="ready"){busy=false;if(!closing)EnabledActions(true);}
                if(smoke&&kind=="ready"){smokeResult=0;closing=true;Send("close");}
            }catch(Exception){Note(e.Data);}});};
            bridge.ErrorDataReceived+=delegate(object sender,DataReceivedEventArgs e){if(e.Data!=null)Post(delegate{Note(e.Data);});};
            bridge.Start();bridge.BeginOutputReadLine();bridge.BeginErrorReadLine();
        }catch(Exception e){Note(e.Message);if(smoke){closing=true;Close();}}
    }
    void Post(Action action){if(!IsDisposed&&IsHandleCreated)try{BeginInvoke(action);}catch(InvalidOperationException){}}
    [STAThread]static int Main(string[] args){Application.EnableVisualStyles();using(var app=new ManualControl(args.Length>0&&args[0]=="--smoke-test")){Application.Run(app);return app.smoke?app.smokeResult:0;}}
}
