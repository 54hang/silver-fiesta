using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;

class LiveSearch {
    static JavaScriptSerializer json=new JavaScriptSerializer{MaxJsonLength=8*1024*1024};
    Stopwatch clock=Stopwatch.StartNew();double seconds,last;string folder;bool stopped;
    long nodes;List<string> path=new List<string>(),best=new List<string>();int bestLeft=int.MaxValue;
    HashSet<string> dead=new HashSet<string>();
    void Save(string name,object value){string p=Path.Combine(folder,name),tmp=p+".tmp";File.WriteAllText(tmp,json.Serialize(value));if(File.Exists(p))File.Replace(tmp,p,null);else File.Move(tmp,p);}
    bool Search(LiveState board){
        nodes++;
        if(clock.Elapsed.TotalSeconds-last>.15){last=clock.Elapsed.TotalSeconds;Save("search_status.json",new{state="searching",nodes,deepest=best.Count,elapsed_seconds=last});string p=Path.Combine(folder,"search_control.json");if(File.Exists(p))try{stopped=Convert.ToString(json.Deserialize<Dictionary<string,object>>(File.ReadAllText(p))["action"])=="stop";}catch(IOException){} }
        if(stopped||clock.Elapsed.TotalSeconds>=seconds){stopped=true;return false;}
        if(board.Complete)return true;
        int left=board.Left.Count+board.Side.Count;
        if(board.Tray.Length<=5&&(left<bestLeft||left==bestLeft&&path.Count>best.Count)){bestLeft=left;best=new List<string>(path);Save("candidate.json",new{sequence=best});}
        string key=board.Key();if(dead.Contains(key))return false;
        var options=board.Left.Concat(board.Side).Where(board.Exposed).Where(id=>board.Tray.Length<6||board.Tray.Count(t=>t==board.Type(id))==2)
            .OrderByDescending(id=>board.Tray.Count(t=>t==board.Type(id))*100+(board.Energy!=null&&board.Energy.Charge(Array.FindIndex(board.Cards,c=>(string)c["id"]==id))>0?25:0)+Convert.ToInt32(board.Cards.First(c=>(string)c["id"]==id)["layer"])).ToArray();
        foreach(string id in options){var next=board.Copy();try{next.Step(id);}catch(Exception){continue;}path.Add(id);if(Search(next))return true;path.RemoveAt(path.Count-1);if(stopped)return false;}
        if(dead.Count<100000)dead.Add(key);return false;
    }
    static int Main(string[] args){try{var s=new LiveSearch{folder=Path.GetDirectoryName(Path.GetFullPath(args[1])),seconds=double.Parse(args[2],System.Globalization.CultureInfo.InvariantCulture)};
        var input=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(args[0]));bool solved=s.Search(new LiveState(input));s.Save("candidate.json",new{sequence=solved?s.path:s.best});s.Save("search_status.json",new{state=solved?"solved":s.stopped?"stopped":"exhausted",nodes=s.nodes,deepest=s.best.Count,elapsed_seconds=s.clock.Elapsed.TotalSeconds});return solved?0:2;
    }catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
