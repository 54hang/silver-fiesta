using System;
using System.Collections.Generic;
using System.Linq;

// Independent C# replay of the original map plus confirmed human operations.
class LiveState {
    public Dictionary<string,object>[] Cards;public ColorRules Colors;public EnergyRules Energy;
    public HashSet<string> Left;public List<string> Side=new List<string>(),TrayIds=new List<string>(),Slot=new List<string>();
    Dictionary<string,int> index;bool movedOut;bool[] picked;
    public static object[] Items(object x){return ((System.Collections.IEnumerable)x).Cast<object>().ToArray();}
    static int N(Dictionary<string,object> c,string k){return Convert.ToInt32(c[k]);}
    public LiveState(Dictionary<string,object> s){
        Cards=Items(s["cards"]).Select(o=>(Dictionary<string,object>)o).ToArray();
        index=Cards.Select((c,i)=>new{Id=(string)c["id"],I=i}).ToDictionary(x=>x.Id,x=>x.I);
        Left=new HashSet<string>(index.Keys);picked=new bool[Cards.Length];
        var rules=s.ContainsKey("rules")?s["rules"] as Dictionary<string,object>:null;
        bool energy=rules!=null&&Convert.ToString(rules["kind"])=="energy_alien_v1";
        if(energy){Energy=new EnergyRules(Cards,rules);Colors=new ColorRules{Types=Cards.Select(c=>N(c,"type")).ToArray(),Special=new int[0]};}
        else Colors=ColorRules.FromSolution(s,Cards);
        foreach(var o in Items(s["history"])) {var a=(Dictionary<string,object>)o;string kind=(string)a["kind"];
            if(kind=="move_out")MoveOut();else if(kind=="board"||kind=="return"){string id=(string)a["id"];if((kind=="return")!=Side.Contains(id))throw new Exception("History location mismatch");Step(id);}else throw new Exception("Unknown history action");}
    }
    public int Type(string id){return Colors.Types[index[id]];}
    public int[] Tray {get{return Energy!=null?Energy.Tray:TrayIds.Select(Type).ToArray();}}
    public bool Complete {get{return Left.Count==0&&Side.Count==0&&Tray.Length==0;}}
    public bool Exposed(string id){
        if(Side.Contains(id))return true;if(!Left.Contains(id))return false;var c=Cards[index[id]];
        return !Left.Any(p=>{var b=Cards[index[p]];return N(b,"layer")>N(c,"layer")&&Math.Abs(N(b,"rolNum")-N(c,"rolNum"))<8&&Math.Abs(N(b,"rowNum")-N(c,"rowNum"))<8;});
    }
    void Sync(){Left=new HashSet<string>(Cards.Where((c,i)=>Energy.Remaining[i]).Select(c=>(string)c["id"]));Side=Energy.SideIds.ToList();Slot=Energy.SlotIds.ToList();}
    public void MoveOut(){
        if(Energy!=null){Energy.MoveOut();Sync();return;}
        if(movedOut||Slot.Count==0)throw new Exception("Move-out unavailable");Side=Slot.Take(3).ToList();Slot=Slot.Skip(3).ToList();TrayIds.RemoveAll(id=>Side.Contains(id));movedOut=true;
    }
    public EnergyRules.Event Step(string id){
        if(!Exposed(id))throw new Exception("Target covered or unavailable");
        if(Energy!=null){var e=Energy.Step(id);Sync();return e;}
        int t=Type(id);TrayIds.Add(id);bool crush=TrayIds.Count(p=>Type(p)==t)==3;
        int last=Slot.FindLastIndex(p=>Type(p)==t);Slot.Insert(last<0?Slot.Count:last+1,id);
        if(crush){TrayIds.RemoveAll(p=>Type(p)==t);Slot.RemoveAll(p=>Type(p)==t);}
        if(TrayIds.Count>=7)throw new Exception("Tray overflow");
        Left.Remove(id);Side.Remove(id);picked[index[id]]=true;if(crush&&Colors.Enabled)Colors.Shuffle(picked);
        return new EnergyRules.Event{Type=t,Tray=Tray,AutoRemoved=new string[0],Crush=crush};
    }
    public LiveState Copy(){var b=(LiveState)MemberwiseClone();b.Left=new HashSet<string>(Left);b.Side=new List<string>(Side);b.TrayIds=new List<string>(TrayIds);b.Slot=new List<string>(Slot);b.picked=(bool[])picked.Clone();b.Colors=new ColorRules{Types=(int[])Colors.Types.Clone(),Special=Colors.Special,A=Colors.A,B=Colors.B,Draws=Colors.Draws};if(Energy!=null)b.Energy=Energy.Copy();return b;}
    public string Key(){return Energy!=null?Energy.Key():string.Join(",",Left.OrderBy(x=>x))+":"+string.Join(",",Colors.Types)+":"+Colors.A+":"+Colors.B+":"+string.Join(",",TrayIds)+":"+string.Join(",",Side);}
}
