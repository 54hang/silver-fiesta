"""Offline recovery and independent native execution gates. No game input."""
import copy
import hashlib
import json
import subprocess
import tempfile
import time
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image, ImageDraw
from live_state import checkpoint, replay, export_route, verify_route
from live_control import history_after, recovery_histories, Controller
from live_recognition import match_state, reconcile, stable_images
from test_energy_rules import fixture as energy_fixture
from test_color_rules import fixture as color_fixture

ROOT=Path(__file__).resolve().parent.parent


def fixture(types=(1,2,3,1,2,3,1,2,3)):
    return {'levelData':{'1':[dict(id=f'c{i}',type=t,rolNum=(i%6)*10,rowNum=(i//6)*12,
                                 metaType=0,metaData=0) for i,t in enumerate(types)]}}


def tile(t):
    image=Image.new('RGB',(34,36),(248,250,210));d=ImageDraw.Draw(image)
    colors={1:(210,55,40),2:(35,120,230),3:(80,190,35),4:(190,45,190),5:(30,180,180),6:(190,120,30),7:(50,40,50)}
    d.rectangle((5,6,28,29),fill=colors[t]);d.line((8,9,25,26),fill='white',width=2)
    return image


CAL=dict(x_origin=42,y_origin=175,x_unit=4.32,y_unit=4.25)


def draw_state(base, history, output):
    board=replay(base['cards'],base.get('rules'),history)
    image=Image.new('RGB',(336,622),(207,252,152))
    ImageDraw.Draw(image).rectangle((20,482,316,542),fill=(110,150,50))
    for id in board.remaining:
        if board.exposed(id):
            c=board.cards[id];x=round(CAL['x_origin']+c['rolNum']*CAL['x_unit']);y=round(CAL['y_origin']+c['rowNum']*CAL['y_unit'])
            image.paste(tile(board.types[id]),(x-17,y-18))
    for k,id in enumerate(board.slot):image.paste(tile(board.types[id]),(43+42*k-17,493))
    for k,id in enumerate(board.side):image.paste(tile(board.types[id]),(90+50*k-17,417))
    image.save(output)
    return image


class StateTests(unittest.TestCase):
    def base(self,data):return checkpoint(data,hashlib.sha256(json.dumps(data).encode()).hexdigest())

    def native(self,folder,base,seconds=2):
        folder.mkdir(exist_ok=True);source=folder/'input.json';source.write_text(json.dumps(base),encoding='utf-8')
        result=subprocess.run([str(ROOT/'LiveSearch.exe'),str(source),str(folder/'candidate.json'),str(seconds)],
                              capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=seconds+8)
        self.assertIn(result.returncode,(0,2),result.stderr)
        return export_route(base,json.loads((folder/'candidate.json').read_text())['sequence'])

    def native_validate(self,folder,solution,data,expect=0):
        mp=folder/'map.json';mp.write_text(json.dumps(data),encoding='utf-8')
        solution=copy.deepcopy(solution);solution['map_sha256']=hashlib.sha256(mp.read_bytes()).hexdigest()
        sp=folder/'solution.json';sp.write_text(json.dumps(solution),encoding='utf-8')
        state=replay(solution['cards'],solution.get('rules'),solution['history'])
        positions={c['id']:[42+(i%6)*43,175+(i//6)*45] for i,c in enumerate(solution['cards'])}
        for k,id in enumerate(state.side):positions[id]=[90+50*k,435]
        plan=dict(solution_path=str(sp),map_sha256=solution['map_sha256'],source_map_path=str(mp),positions=positions,anchors=[],allow_live=True,start_step=0)
        pp=folder/'plan.json';pp.write_text(json.dumps(plan),encoding='utf-8')
        result=subprocess.run([str(ROOT/'SolverPlayback.exe'),str(pp),'--validate-only'],capture_output=True,
                              creationflags=subprocess.CREATE_NO_WINDOW,timeout=8)
        self.assertEqual(result.returncode,expect,result.stdout+result.stderr)

    def test_full_routes_and_partial_routes_replay_in_two_engines(self):
        for data in (fixture(),color_fixture(),energy_fixture()):
            with self.subTest(kind=bool(data.get('goldBlockData'))),tempfile.TemporaryDirectory() as tmp:
                folder=Path(tmp);base=self.base(data);solution=self.native(folder,base)
                self.assertTrue(solution['complete']);verify_route(solution)
                self.native_validate(folder,solution,data)
                partial=export_route(base,solution['sequence'][:2]);self.assertFalse(partial['complete'])
                self.native_validate(folder,partial,data)

    def test_partial_overflow_is_trimmed_and_not_mislabeled_complete(self):
        data=fixture((1,2,3,4,5,6,7));base=self.base(data)
        solution=export_route(base,[f'c{i}' for i in range(7)])
        self.assertEqual(len(solution['sequence']),5)
        self.assertFalse(solution['complete']);self.assertFalse(solution['validated'])
        with tempfile.TemporaryDirectory() as tmp:self.native_validate(Path(tmp),solution,data)
        bad=copy.deepcopy(solution);bad['sequence']=[f'c{i}' for i in range(7)];bad.pop('sequence_types')
        with self.assertRaises(ValueError):verify_route(bad)
        with tempfile.TemporaryDirectory() as tmp:self.native_validate(Path(tmp),bad,data,1)

    def test_covered_and_repeated_targets_do_not_reach_input(self):
        data=fixture();data['levelData']['2']=[dict(id='cover',type=1,rolNum=0,rowNum=0)]
        base=self.base(data)
        self.assertEqual(export_route(base,['c0'])['sequence'],[])
        good=export_route(base,['cover','c0']);bad=copy.deepcopy(good);bad['sequence'].append('c0')
        with self.assertRaises(ValueError):verify_route(bad)
        with tempfile.TemporaryDirectory() as tmp:self.native_validate(Path(tmp),bad,data,1)

    def test_move_out_returns_and_energy_alien_from_actual_checkpoint(self):
        # Hold three types, move out, then ask both engines to finish using
        # returns. Batteries remain charged until the resumed route picks one.
        for energy in (False,True):
            data=fixture((1,2,3,1,2,3,1,2,3,4,4,4))
            if energy:
                data.update(map_seed=[697634228,2420934636,717715288,3972332771],blockTypeData={'1':1,'2':1,'3':1,'4':1},
                            goldBlockData={'collectCount':1,'blockList':[{'val':4}]})
            base=self.base(data);base['history']=[dict(kind='board',id=f'c{i}') for i in range(3)]+[dict(kind='move_out')]
            with self.subTest(energy=energy),tempfile.TemporaryDirectory() as tmp:
                solution=self.native(Path(tmp),base,3);self.assertTrue(solution['complete'])
                self.native_validate(Path(tmp),solution,data)
                board=replay(base['cards'],base.get('rules'),history_after(solution,len(solution['sequence'])))
                self.assertFalse(board.side);self.assertFalse(board.tray)

    def test_classic_move_out_returns_count_as_picked_tiles(self):
        data=fixture();base=self.base(data)
        base['history']=[dict(kind='board',id=f'c{i}') for i in range(3)]+[dict(kind='move_out')]
        board=replay(base['cards'],None,base['history'])
        self.assertEqual(len(board.remaining),6);self.assertEqual(len(board.side),3)
        solution=export_route(base,[f'c{i}' for i in range(3,9)]+['c0','c1','c2'])
        self.assertTrue(solution['complete']);verify_route(solution)

    def test_native_tampered_types_and_complete_flags_are_rejected(self):
        data=fixture();base=self.base(data);partial=export_route(base,['c0','c1'])
        for key,value in [('complete',True),('sequence_types',[99,99]),('expected_tray',[])]:
            with self.subTest(key=key),tempfile.TemporaryDirectory() as tmp:
                bad=dict(partial,**{key:value});self.native_validate(Path(tmp),bad,data,1)

    def test_manual_stop_preserves_a_verified_prefix_and_releases_process(self):
        # One hundred unique types cannot win and produces a large search.
        data=fixture(tuple(range(1,101)));base=self.base(data)
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);(folder/'input.json').write_text(json.dumps(base))
            child=subprocess.Popen([str(ROOT/'LiveSearch.exe'),str(folder/'input.json'),str(folder/'candidate.json'),'120'],
                                   creationflags=subprocess.CREATE_NO_WINDOW,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            try:
                deadline=time.monotonic()+5
                while not (folder/'search_status.json').exists() and time.monotonic()<deadline:time.sleep(.02)
                (folder/'search_control.json').write_text('{"action":"stop"}')
                child.communicate(timeout=5)
                self.assertEqual(child.returncode,2)
                solution=export_route(base,json.loads((folder/'candidate.json').read_text())['sequence']);verify_route(solution)
                self.assertGreater(len(solution['sequence']),0)
                self.assertLessEqual(len(solution['expected_tray']),5)
                self.assertEqual(json.loads((folder/'search_status.json').read_text())['state'],'stopped')
            finally:
                if child.poll() is None:child.kill();child.wait()


class VisualRecoveryTests(unittest.TestCase):
    def test_actual_board_tray_and_move_out_area_then_undo(self):
        data=fixture();base=checkpoint(data,'fixture');history=[dict(kind='board',id=f'c{i}') for i in range(3)]
        templates={t:[np.asarray(tile(t),dtype=np.int16)] for t in (1,2,3)}
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'board.png'
            for actual in (history,history+[dict(kind='move_out')],history[:-1]):
                draw_state(base,actual,p)
                recovered,observed=reconcile(p,base,recovery_histories(base,history),CAL,templates)
                self.assertEqual(recovered,actual)
                self.assertEqual(observed['side'],[1,2,3] if len(actual)==4 else [])
            moved=history+[dict(kind='move_out')];image=draw_state(base,moved,p)
            image.paste(tile(3),(90-17,417));image.save(p)
            with self.assertRaises(ValueError):reconcile(p,base,recovery_histories(base,history),CAL,templates)

    def test_equal_slot_count_with_wrong_icons_blocks_reuse(self):
        base=checkpoint(fixture(),'fixture');history=[dict(kind='board',id='c0')]
        templates={t:[np.asarray(tile(t),dtype=np.int16)] for t in (1,2,3)}
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'board.png';image=draw_state(base,history,p)
            image.paste(tile(2),(26,493));image.save(p)
            with self.assertRaises(ValueError):match_state(p,base,history,CAL,templates)

    def test_single_changed_tile_invalidates_route_despite_small_global_difference(self):
        base=checkpoint(fixture(),'fixture')
        with tempfile.TemporaryDirectory() as tmp:
            a=Path(tmp)/'a.png';b=Path(tmp)/'b.png';image=draw_state(base,[],a);image.save(b)
            stable_images(a,b)
            image.paste(tile(3),(42-17,175-18));image.save(b)
            with self.assertRaises(ValueError):stable_images(a,b)

    def test_ambiguous_state_and_missing_side_are_blocked(self):
        base=checkpoint(fixture(),'fixture');history=[dict(kind='board',id=f'c{i}') for i in range(3)]
        moved=history+[dict(kind='move_out')];templates={t:[np.asarray(tile(t),dtype=np.int16)] for t in (1,2,3)}
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'board.png';draw_state(base,moved,p)
            with self.assertRaisesRegex(ValueError,'多个'):reconcile(p,base,[moved,moved],CAL,templates)
            image=Image.open(p);ImageDraw.Draw(image).rectangle((70,410,210,460),fill=(207,252,152));image.save(p)
            with self.assertRaises(ValueError):match_state(p,base,moved,CAL,templates)


class ControllerTests(unittest.TestCase):
    def test_refresh_after_move_out_can_search_again_without_replaying_old_clicks(self):
        import live_control
        with tempfile.TemporaryDirectory() as tmp:
            session=Path(tmp)/'session';session.mkdir();mp=session/'map_0.json';data=fixture()
            mp.write_text(json.dumps(data),encoding='utf-8')
            status=dict(session='session',map_ids=['fixture'],source_path='/sheep/v1/game/world/game_start')
            base=checkpoint(data,hashlib.sha256(mp.read_bytes()).hexdigest());image=session/'now.png';draw_state(base,[],image)
            controller=Controller(notify=lambda message:None)
            with patch('world_solution.current',return_value=(status,mp)),patch('world_solution.active_session'),patch.object(controller,'capture_pair',return_value=image),patch('live_control.inspect_board',return_value=dict(level=0,calibration=CAL)):
                controller.refresh();controller.selection=export_route(base,['c0','c1','c2'])
                # Produce the same on-disk evidence as three confirmed native
                # clicks, without starting a game or sending any input.
                play=session/'live/run-test';play.mkdir();solution=controller.selection
                sp=play/'solution.json';sp.write_text(json.dumps(solution))
                plan=dict(controller.saved['reference_plan'],solution_path=str(sp),positions=controller.saved['observed']['positions'],play_folder=str(play))
                pp=play/'plan.json';pp.write_text(json.dumps(plan))
                (play/'playback_status.json').write_text(json.dumps(dict(next_step=3,input_pending=False)))
                (play/'actions.jsonl').write_text('\n'.join(json.dumps(dict(step=i+1,card_id=id)) for i,id in enumerate(solution['sequence'])))
                history=history_after(solution,3);draw_state(base,history,play/'last_verified.png')
                controller.saved['plan_path']=str(pp);controller.saved_path.write_text(json.dumps(controller.saved))
                moved=history+[dict(kind='move_out')];draw_state(base,moved,image)
                controller.refresh()
                self.assertEqual(controller.saved['base']['history'],moved)
                self.assertEqual(controller.saved['observed']['side'],[1,2,3])
                controller.search(seconds=2)
                self.assertTrue(controller.selection['complete'])
                self.assertEqual(controller.selection['history'],moved)
                self.assertTrue(any(id in ('c0','c1','c2') for id in controller.selection['sequence']))
                self.assertIsNone(controller.process)

    def test_refresh_failure_disables_previously_ready_route(self):
        controller=Controller();controller.ready=True;controller.selection={'old':True}
        with patch('world_solution.current',side_effect=ValueError('地图未就绪')):
            with self.assertRaises(ValueError):controller.refresh()
        self.assertFalse(controller.ready)
        with self.assertRaises(ValueError):controller.play()

    def test_pending_click_is_reconciled_from_screen_without_duplicate_input(self):
        base=checkpoint(fixture(),'fixture');history=[dict(kind='board',id='c0')]
        candidates=recovery_histories(base,history,pending='c1')
        templates={t:[np.asarray(tile(t),dtype=np.int16)] for t in (1,2,3)}
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'now.png';actual=history+[dict(kind='board',id='c1')];draw_state(base,actual,p)
            found,_=reconcile(p,base,candidates,CAL,templates)
            self.assertEqual(found,actual)

    def test_capture_does_not_search_automatically_by_default(self):
        from world_capture import WorldCapture
        with tempfile.TemporaryDirectory() as tmp:
            capture=WorldCapture(Path(tmp),auto_download=False,crypto_probe=False,publish_legacy=False)
            try:self.assertFalse(capture.auto_solve)
            finally:capture.pool.shutdown(wait=True,cancel_futures=True);capture.done()


if __name__=='__main__':unittest.main()
