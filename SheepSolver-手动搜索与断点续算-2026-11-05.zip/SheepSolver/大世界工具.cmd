@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if /i "%~1"=="--check" goto check
title 羊了个羊大世界工具
:menu
cls
echo 羊了个羊大世界工具
echo.
echo 1. 启动抓包（保留窗口，再进入游戏）
echo 2. 查看已求解路线
echo 3. 核对当前棋盘
echo 4. 手动搜索、停止、部分路线执行、道具后续算
echo 5. 手动搜索完整路线（旧命令行入口）
echo 0. 退出
echo.
choice /c 123450 /n /m "请选择："
if errorlevel 6 exit /b
if errorlevel 5 goto solve
if errorlevel 4 goto play
if errorlevel 3 goto prepare
if errorlevel 2 goto show
start "" "%~dp0capture-world.cmd"
goto menu
:show
start "" "%~dp0查看大世界路线.cmd"
goto menu
:prepare
start "" "%~dp0核对大世界棋盘.cmd"
goto menu
:play
start "" "%~dp0手动搜索与续算.cmd"
goto menu
:solve
start "" "%~dp0solve-local.cmd"
goto menu
:check
if not exist "%~dp0.venv\Scripts\python.exe" exit /b 1
if not exist "%~dp0.venv\Scripts\mitmdump.exe" exit /b 2
if not exist "%~dp0capture-world.cmd" exit /b 3
if not exist "%~dp0world_solution.py" exit /b 4
if not exist "%~dp0world_support\SolverPlayback.exe" exit /b 5
if not exist "%~dp0world_support\SheepClicker.Diagnostics.exe" exit /b 6
"%~dp0.venv\Scripts\python.exe" -c "import mitmproxy, win32gui, numpy, PIL; print('WeChat launcher dependency check passed.')"
exit /b %errorlevel%
