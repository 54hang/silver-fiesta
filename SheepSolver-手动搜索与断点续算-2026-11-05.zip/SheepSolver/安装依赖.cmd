@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    py -3.12 -m venv .venv
    if errorlevel 1 goto fail
)
".venv\Scripts\python.exe" -m pip install -r requirements-world-test.txt
if errorlevel 1 goto fail
echo 安装完成。请开启 capture-world.cmd，再打开手动搜索与续算.cmd。
pause
exit /b 0
:fail
echo 安装失败。请先安装 Python 3.12（含 Windows py 启动器）并查看上方错误。
pause
exit /b 1
