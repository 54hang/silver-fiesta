@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONPATH=%~dp0;%~dp0world_support
start "" "%~dp0world_support\ManualControl.exe"
if errorlevel 1 pause
