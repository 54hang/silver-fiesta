@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
set "PYTHONPATH=%~dp0;%~dp0world_support;%~dp0world_support\tests"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-world.ps1"
if errorlevel 1 goto end
"%~dp0world_support\ManualControl.exe" --smoke-test
if errorlevel 1 goto end
"%~dp0.venv\Scripts\python.exe" -m unittest discover -s world_support/tests -v
:end
pause
