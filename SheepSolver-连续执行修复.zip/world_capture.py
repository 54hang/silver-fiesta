"""World-mode integration for the original SheepSolver installation."""
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
SUPPORT = ROOT / 'world_support'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(SUPPORT))
from auto_capture import AutoCapture, write_json


class WorldCapture(AutoCapture):
    def __init__(self, output=None, auto_download=True, auto_solve=True, crypto_probe=True, publish_legacy=True):
        # mitmproxy reloads this script; imported helpers otherwise stay cached.
        import importlib
        import world_search
        importlib.reload(world_search)
        self._last_notice = None
        self._publish_legacy = publish_legacy
        self._closing = False
        print('\n===== SheepSolver 大世界适配版 v2 =====', flush=True)
        print('请保持本窗口打开，然后重新进入大世界关卡。', flush=True)
        super().__init__(output or ROOT / 'runtime/world', auto_download, auto_solve, crypto_probe)

    def status(self, **changes):
        super().status(**changes)
        write_json(self.out / 'service_lease.json', {'running': True, 'pid': os.getpid()})
        notice = (self.state.get('phase'), self.state.get('seed_received'),
                  self.state.get('solver'), self.state.get('seed_source'),
                  self.state.get('message'))
        if notice != self._last_notice:
            self._last_notice = notice
            message = self.state.get('message', '')
            if self.state.get('phase') == 'waiting_for_seed_decryption':
                message = ('已收到加密种子，正在验证游戏本机解密参数。'
                           '若一直停在此处，需要在保持抓包的情况下正常完成或失败一局，'
                           '让脚本取得同一加密版本的结算验证数据；之后重新进入目标关卡。')
            solver = self.state.get('solver')
            if solver == 'running':
                message = '当前关卡牌型已还原，正在限时搜索并独立验证完整路线。'
            elif solver == 'solved':
                message = '完整路线已通过回放验证。请打开本项目的“查看大世界路线.cmd”。'
            elif solver in ('no_solution_within_limit', 'timed_out'):
                message = '未算出本关完整通关路线，搜索已终止，自动通关已停止；不会自动重试。'
            print('=====> ' + message, flush=True)
            if self.state.get('seed_source'):
                print('=====> 种子验证来源: ' + self.state['seed_source'], flush=True)

    def finalize(self):
        super().finalize()
        if not self.current or not self.state.get('complete'):
            return
        current_map = Path(self.state['current_map'])
        payload = json.loads(current_map.read_text(encoding='utf-8'))
        if payload.get('_acquisition', {}).get('session') != self.current['id']:
            raise ValueError('地图与当前局不匹配')
        if self._publish_legacy:
            write_json(ROOT / 'online_data.json', payload)

    def solve_current(self, session, map_path):
        from color_rules import compatibility
        data = json.loads(map_path.read_text(encoding='utf-8'))
        if compatibility(data) not in ('standard', 'color_shuffle', 'energy_alien') or data.get('_resumed_state'):
            with self.lock:
                if self.current and self.current['id'] == session:
                    self.status(solver='unsupported_state', message='地图已还原，但当前特殊规则或已进行牌槽状态尚不支持求解。')
            return
        output = map_path.parent / 'solution'
        output.mkdir(exist_ok=True)
        with self.lock:
            if not self.current or self.current['id'] != session:
                return
            self.status(solver='running')
        state = 'no_solution_within_limit'
        try:
            from world_search import search
            def still_current():
                if self._closing or not self.current or self.current['id'] != session:
                    raise ValueError('已换局，停止旧局搜索。')
            if search(map_path, output, seconds=120, rounds=1, active=still_current,
                      cancel=lambda: False, notify=lambda text: print('=====> ' + text, flush=True)):
                state = 'solved'
        except TimeoutError:
            state = 'timed_out'
        except (ValueError, OSError, KeyError):
            state = 'validation_failed'
        with self.lock:
            if not self._closing and self.current and self.current['id'] == session:
                self.status(solver=state, solution_path=str(output / 'solution.json') if state == 'solved' else None)

    def done(self):
        # The base module is imported as auto_capture, so its __mitmproxy_script__
        # condition never applies to this wrapper. Preserve the same handoff here.
        import capture_runtime
        with self.lock:
            self._closing = True
            names = ('current', 'maps', 'crypto', 'cipher_pending', 'streams',
                     'seed_prefix', 'state', 'start_request', 'start_accepted')
            values = {name: getattr(self, name) for name in names}
            values['crypto'] = list(values['crypto'])
            values['cipher_pending'] = list(values['cipher_pending'])
            values['streams'] = dict(values['streams'])
            values['state'] = dict(values['state'])
            if self.current and self.state.get('solver') == 'running':
                values['current'] = dict(self.current, solve_started=False)
            capture_runtime.handoff = {'pid': os.getpid(), 'out': str(self.out), 'values': values}
        super().done()
        write_json(self.out / 'service_lease.json', {'running': False, 'pid': os.getpid()})


if __name__.startswith('__mitmproxy_script__.'):
    addons = [WorldCapture()]
