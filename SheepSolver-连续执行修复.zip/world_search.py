"""One bounded attempt per map; a failed attempt also stops automatic play."""
import hashlib
import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SUPPORT = ROOT / 'world_support'


def stopped():
    return bool(ctypes.windll.user32.GetAsyncKeyState(0x78) & 0x8000)


def read_json(path):
    try:
        return json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):
        return {}


def progress_message(state, elapsed, now=None):
    """The longest candidate is a high water mark, not a completion percent."""
    now = time.time() if now is None else now
    if not state:
        return f'求解器启动中，已用 {elapsed:.0f} 秒。'
    if state.get('updated_at_unix') and now - state['updated_at_unix'] > 15:
        return f'求解器进度暂未更新，已用 {elapsed:.0f} 秒；等待进程响应。'
    if state.get('state') == 'validating':
        return '已找到完整候选，正在独立回放验证。'
    if state.get('state') == 'solved':
        return '完整路线已通过独立验证，搜索结束。'
    nodes = state.get('nodes', 0)
    amount = f'{nodes / 100000000:.2f} 亿' if nodes >= 100000000 else f'{nodes / 10000:.1f} 万'
    speed = max(0, state.get('nodes_per_second', 0)) / 10000
    message = '地图 {} 张已还原；最长候选 {} 步（尚未通关）；本轮检查 {} 状态，约 {:.1f} 万/秒，已用 {:.0f} 秒。'.format(
        state.get('total', '?'), state.get('deepest', 0), amount, speed, elapsed)
    if state.get('seconds_without_improvement', 0) >= 15:
        message += '正在回退、排除其他路线，最长候选步数可能暂时不变。'
    return message


def verified_answer(map_path, output):
    import hashlib
    from desktop_assistant import validate_solution
    answer = read_json(output / 'solution.json')
    if not answer:
        return None
    if answer.get('validated') is not True or answer.get('map_sha256') != hashlib.sha256(map_path.read_bytes()).hexdigest():
        raise ValueError('答案与当前地图不符。')
    validate_solution(answer)
    return answer


def failure_for(map_path, output):
    failure = read_json(output / 'search_failure.json')
    if failure.get('map_sha256') == hashlib.sha256(map_path.read_bytes()).hexdigest():
        return failure
    return None


def stop_without_solution(map_path, output, seconds, reason, notify):
    level = read_json(map_path).get('_acquisition', {}).get('level_index', 0) + 1
    message = (f'第 {level} 关：{seconds} 秒内未算出完整通关路线，搜索已终止，自动通关已停止。'
               if reason in ('limited', 'timed_out') else
               f'第 {level} 关：搜索结束后未找到完整通关路线，搜索已终止，自动通关已停止。')
    payload = {'map_sha256': hashlib.sha256(map_path.read_bytes()).hexdigest(),
               'reason': reason, 'message': message, 'seconds': seconds,
               'terminated': True, 'updated_at_unix': time.time()}
    temporary = output / 'search_failure.tmp'
    temporary.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    os.replace(temporary, output / 'search_failure.json')
    notify(message)
    return False


def search(map_path, output, seconds=120, rounds=1, active=None, cancel=stopped,
           notify=print, force=False):
    """Serialize capture/play searches without ever trusting a partial prefix."""
    import msvcrt
    if rounds != 1:
        raise ValueError('自动重试已停用；每次只进行一轮限时搜索。')
    output.mkdir(parents=True, exist_ok=True)
    lock_path = output / 'search.lock'
    with lock_path.open('a+b') as lock:
        lock.seek(0, os.SEEK_END)
        if not lock.tell():
            lock.write(b'\0')
            lock.flush()
        announced = False
        while True:
            if cancel():
                raise ValueError('F9 已停止自动执行。')
            if active:
                active()
            try:
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
                break
            except OSError:
                if not announced:
                    notify('另一窗口正在搜索本关，等待它结束后复用结果。')
                    announced = True
                time.sleep(.3)
        try:
            if not force and verified_answer(map_path, output):
                return True
            failure = failure_for(map_path, output)
            if failure and not force:
                notify(failure['message'])
                return False
            # Only an explicit manual solve may start again after failure.
            (output / 'search_failure.json').unlink(missing_ok=True)
            identity = read_json(map_path).get('_acquisition', {})
            label = identity.get('level_index', 0) + 1
            env = dict(os.environ, PYTHONPATH=os.pathsep.join((str(ROOT), str(SUPPORT))), PYTHONUTF8='1')
            for attempt in range(1, rounds + 1):
                if cancel():
                    raise ValueError('F9 已停止自动执行。')
                if active:
                    active()
                notify(f'第 {label} 关：限时搜索 {seconds} 秒；算不出即停止，不自动重试。F9 停止。')
                command = [sys.executable, str(SUPPORT / 'solve_verified_map.py'), '--map', str(map_path),
                           '--time-limit', str(seconds), '--mode', 'level-top', '--output', str(output)]
                with (output / 'solver-process.log').open('a', encoding='utf-8') as log:
                    process = subprocess.Popen(command, cwd=SUPPORT, env=env, stdout=log, stderr=log,
                                               creationflags=subprocess.CREATE_NO_WINDOW)
                    started = last_report = time.monotonic()
                    try:
                        while process.poll() is None:
                            if cancel():
                                raise ValueError('F9 已停止自动执行。')
                            if active:
                                active()
                            now = time.monotonic()
                            if now - started > seconds + 30:
                                raise TimeoutError('求解器超过预期退出时间，请查看 solver-process.log。')
                            if now - last_report >= 5:
                                state = read_json(output / 'search_status.json')
                                notify(progress_message(state, now - started))
                                last_report = now
                            time.sleep(.2)
                        code = process.wait()
                    finally:
                        if process.poll() is None:
                            # Ask the wrapper to unwind and reap its own workers.
                            (output / 'search_control.json').write_text('{"action":"stop"}', encoding='utf-8')
                            try:
                                process.wait(timeout=10)
                            except subprocess.TimeoutExpired:
                                subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                                               capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
                                process.wait(timeout=5)
                if code == 0 and verified_answer(map_path, output):
                    return True
                state = read_json(output / 'search_status.json')
                if code != 2 or state.get('state') not in ('limited', 'exhausted'):
                    raise ValueError('求解器异常停止，请查看本关 solver-process.log。')
                return stop_without_solution(map_path, output, seconds, state['state'], notify)
        except TimeoutError:
            return stop_without_solution(map_path, output, seconds, 'timed_out', notify)
        finally:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
