"""Read, solve or display only the currently captured world-session route."""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from world_search import search, stopped, read_json

ROOT = Path(__file__).resolve().parent
SUPPORT = ROOT / 'world_support'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(SUPPORT))


def current():
    status_path = ROOT / 'runtime/world/status.json'
    if not status_path.exists():
        raise ValueError('尚未运行大世界适配版抓包脚本。')
    status = json.loads(status_path.read_text(encoding='utf-8'))
    if status.get('complete') is not True or not status.get('current_map'):
        raise ValueError('当前局牌型尚未完整还原。' + status.get('message', ''))
    path = Path(status['current_map']).resolve()
    if not path.is_relative_to((ROOT / 'runtime/world/sessions').resolve()):
        raise ValueError('地图不属于本项目的采集目录。')
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('_acquisition', {}).get('session') != status.get('session'):
        raise ValueError('地图与当前局号不一致。')
    return status, path


@contextmanager
def execution_lock():
    import msvcrt
    path = ROOT / 'runtime/world/execution.lock'
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as lock:
        lock.seek(0, os.SEEK_END)
        if not lock.tell():
            lock.write(b'\0')
            lock.flush()
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            raise ValueError('已有自动执行窗口正在运行，请先在原窗口按 F9 停止。')
        try:
            yield
        finally:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)


def active_session(status):
    newest, _ = current()
    if newest.get('session') != status.get('session'):
        raise ValueError('搜索期间已换局，请使用新局路线。')
    from capture_service import alive
    lease = json.loads((ROOT / 'runtime/world/service_lease.json').read_text(encoding='utf-8'))
    if not lease.get('running') or not alive(lease.get('pid', 0)):
        raise ValueError('请保持大世界抓包窗口打开。')


def execute(args, status, path, selection=None):
    raw = None
    if args.action in ('prepare', 'play'):
        import app_bridge
        app_bridge.OUT = ROOT / 'runtime/world'
        if selection is None:
            raw = app_bridge.capture_snapshot(ROOT / 'runtime/world/board-now.png')
            selection = app_bridge.inspect_board(path.parent, raw, len(status['map_ids']))
        if selection.get('resume'):
            raise ValueError('当前关已有点击记录。自动从头执行已停用，需要核对断点后才能继续。')
        path = path.parent / ('map_{}.json'.format(selection['level']))
        print('已识别屏幕上是本局第 {} 关。'.format(selection['level'] + 1), flush=True)
    data = json.loads(path.read_text(encoding='utf-8'))
    identity = data.get('_acquisition', {})
    index = identity.get('level_index')
    if (identity.get('session') != status.get('session') or not isinstance(index, int)
            or not 0 <= index < len(status['map_ids']) or identity.get('map_md5') != status['map_ids'][index]):
        raise ValueError('地图与当前关次身份不一致。')
    output = path.parent / ('solution' if index == len(status['map_ids']) - 1 else 'level_{}_solution'.format(index))
    if args.action == 'solve' or (args.action == 'play' and not (output / 'solution.json').exists()):
        if not search(path, output, args.seconds, args.rounds, active=lambda: active_session(status),
                      notify=lambda message: print(message, flush=True), force=args.action == 'solve'):
            raise ValueError('未算出本关完整通关路线，搜索和自动通关已终止；不会自动重试。')
    answer_path = output / 'solution.json'
    if not answer_path.exists():
        raise ValueError('当前关卡尚无完整路线；可运行 solve-local.cmd 搜索。')
    answer = json.loads(answer_path.read_text(encoding='utf-8'))
    from desktop_assistant import validate_solution
    if answer.get('validated') is not True or answer.get('map_sha256') != hashlib.sha256(path.read_bytes()).hexdigest():
        raise ValueError('答案与当前地图不符。')
    validate_solution(answer)
    if stopped():
        raise ValueError('F9 已停止自动执行。')
    # Recheck the active capture after a potentially long search.
    newest, newest_path = current()
    if newest.get('session') != status.get('session') or newest_path.parent != path.parent:
        raise ValueError('搜索期间已换局，请使用新局路线。')
    print('路线回放验证通过，共 {} 步。'.format(len(answer['sequence'])))
    if args.action == 'show':
        os.startfile(str(output / '点击预演.html'))
    if args.action in ('prepare', 'play'):
        import app_bridge
        app_bridge.OUT = ROOT / 'runtime/world'
        data = json.loads(path.read_text(encoding='utf-8'))
        mode = 'world' if '/world/' in status.get('source_path', '') else 'daily'
        level = data['_acquisition']['level_index']
        lease = json.loads((ROOT / 'runtime/world/service_lease.json').read_text(encoding='utf-8'))
        if not lease.get('running'):
            raise ValueError('请保持大世界抓包窗口打开。')
        # Search may take a minute; capture and recheck the board again.
        raw = app_bridge.capture_snapshot(output / 'current-board.png')
        prepared = app_bridge.prepare(path.parent, path, data, level, mode,
                                      image_path=raw, solution_path=answer_path, refit=True)
        newest, _ = current()
        if newest.get('session') != status.get('session'):
            raise ValueError('棋盘核对期间已经换局，停止执行。')
        if args.action == 'prepare':
            print(prepared['message'])
            os.startfile(prepared['preview_path'])
        else:
            print('棋盘已核对，开始自动执行。F8 暂停/继续，F9 停止。请保持游戏窗口可见且不移动。', flush=True)
            result = subprocess.run([str(SUPPORT / 'SolverPlayback.exe'), prepared['plan_path']], cwd=SUPPORT)
            if result.returncode:
                raise ValueError('执行已停止，请查看上方的牌面核对提示；不要从头重复点击。')
            print('本关计划已执行；是否通关请以游戏成功画面为准。')
    return status['session'], index


def watch(args):
    """Wait for a stable complete board, then solve and play that board once."""
    import app_bridge
    from app_bridge import AwaitBoard
    app_bridge.OUT = ROOT / 'runtime/world'
    completed = set()
    previous = None
    stable = 0
    deadline = time.monotonic() + args.wait_seconds
    last_notice = None
    print('连续执行已开启：等待完整棋盘，通关后继续识别下一关。F9 停止。', flush=True)
    while time.monotonic() < deadline:
        if stopped():
            raise ValueError('F9 已停止自动执行。')
        capture_state = read_json(ROOT / 'runtime/world/status.json')
        if not capture_state.get('complete') or not capture_state.get('current_map'):
            previous, stable = None, 0
            notice = '等待抓包窗口还原新一局的完整地图。'
            if notice != last_notice:
                print(notice, flush=True)
                last_notice = notice
            time.sleep(.5)
            continue
        try:
            status, path = current()
            active_session(status)
            image = app_bridge.capture_snapshot(ROOT / 'runtime/world/board-now.png')
            selection = app_bridge.inspect_board(path.parent, image, len(status['map_ids']))
            if selection.get('resume'):
                raise ValueError('当前关已有点击记录。请核对断点；连续执行不会从头重复点击。')
            key = status['session'], selection['level']
            if key in completed:
                previous, stable = None, 0
                notice = '本关已执行，等待游戏显示下一关棋盘；若停在结算页，请进入下一关。'
            else:
                stable = stable + 1 if previous == key else 1
                previous = key
                notice = f'已发现第 {selection["level"] + 1} 关，等待棋盘稳定。'
                if stable >= 2:
                    completed.add(execute(args, status, path, selection))
                    previous, stable = None, 0
                    deadline = time.monotonic() + args.wait_seconds
                    notice = '本关已执行，等待游戏显示下一关棋盘；若停在结算页，请进入下一关。'
        except AwaitBoard as error:
            previous, stable = None, 0
            notice = str(error)
        if notice != last_notice:
            print(notice, flush=True)
            last_notice = notice
        time.sleep(.5)
    print(f'{args.wait_seconds} 秒内未出现可执行的新棋盘，连续执行已结束。', flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['status', 'solve', 'show', 'prepare', 'play'])
    parser.add_argument('--seconds', type=int, default=120)
    parser.add_argument('--rounds', type=int, default=1, choices=[1], help='only one attempt; automatic retries disabled')
    parser.add_argument('--watch', action='store_true', help='continue when the next stable board appears')
    parser.add_argument('--wait-seconds', type=int, default=180)
    args = parser.parse_args()
    if not 1 <= args.seconds <= 300 or not 1 <= args.wait_seconds <= 3600:
        parser.error('seconds: 1..300; wait-seconds: 1..3600')
    if args.watch and args.action != 'play':
        parser.error('--watch requires play')
    if args.action == 'play':
        with execution_lock():
            if args.watch:
                return watch(args)
            status, path = current()
            return execute(args, status, path)
    status, path = current()
    if args.action == 'status':
        print(json.dumps(status, ensure_ascii=False, indent=2))
        return
    execute(args, status, path)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError) as error:
        print('=====> ' + str(error))
        raise SystemExit(1)
    except KeyboardInterrupt:
        print('已停止自动执行。')
        raise SystemExit(1)
